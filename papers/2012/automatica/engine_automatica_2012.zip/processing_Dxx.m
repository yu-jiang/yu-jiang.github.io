function Dxx=processing_Dxx(Dxx)
global xn

% processing the Dxx matrix
ij=[];
ii=[];

for i=1:xn
      ii=[ii (i-1)*xn+i];
end


for i=1:xn-1
  for j=i+1:xn
      ij=[ij (i-1)*xn+j];
  end
end

Dxx(:,ii)=Dxx(:,ii)/2;
Dxx(:,ij)=[];
Dxx=Dxx*2;
