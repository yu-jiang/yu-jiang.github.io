% Code for the paper "Computational adaptive optimal control with an
% application to a car engine control problem",  Yu Jiang and Zhong-Ping
% Jiang, Automatica, 2012.

clear all
global A B xn un i1 i2 K flag
clc
warning off % Turn of the warning for close to singularities

x_save=[];
t_save=[];
flag=1;  % 1: learning is on. 0: learning is off.
%%%%Here are the parameters need to be specified


%% 1 System parameters

% System matrices used for simulation purpose


A=[-0.4125    -0.0248   0.0741   0.0089   0             0;
  101.5873    -7.2651   2.7608   2.8068   0             0;
    0.0704     0.0085  -0.0741  -0.0089   0        0.0200;
    0.0878     0.2672        0  -0.3674   0.0044   0.3962;
   -1.8414     0.0990        0        0  -0.0343  -0.0330;
         0          0        0     -359 187.5364 -87.0316];
     
B=[-0.0042 0.0064
   -1.0360 1.5849
    0.0042 0;
    0.1261 0;
    0     -0.0168;
    0      0];


[xn,un]=size(B);%size of x

% Set the weighting matrices for the cost function
Q=diag([1 1 0.1 0.1 0.1 0.1]);
R=eye(2);

% initialize the feedback gain matrix
K=zeros(un,xn);  % only for A is Hurwitz
N=200;  %length of the window, should be at least greater than xn^2
NN=10;  %max iteration times
T=.01;dt=0.0001; % period to data recording
%T=1;dt=0.01;


%x0=[10;2;100;2;-1;-2]; %initial condition
x0=[10;2;10;2;-1;-2]; 
i1=(rand(1,100)-.5)*1000;
i2=(rand(1,100)-.5)*1000;
%%%%%%



Dxx=[];
XX=[];
XU=[];
X=[x0;kron(x0',x0')';kron(x0,zeros(un,1))]';


% run the simulation and obtain the data matrices \delta_{xx}, I_{xx}, and
% I_{xu}

for i=1:N
    N-i %show you how many steps are left
[t,X]=ode_yuri((i-1)*T,i*T,X(end,:)',dt);
Dxx=[Dxx;
    kron(X(end,1:xn),X(end,1:xn))-kron(X(1,1:xn),X(1,1:xn))];
XX=[XX;
    X(end,xn+1:xn+xn^2)-X(1,xn+1:xn+xn^2)];
XU=[XU;
    X(end,xn+xn^2+1:end)-X(1,xn+xn^2+1:end)];

x_save=[x_save;X];
t_save=[t_save;t'];
end

Dxx=processing_Dxx(Dxx); % Only the distinct columns left

%% ADP learning
% K=zeros(un,xn);  % Initial stabilizing feedback gain matrix
P_old=zeros(xn); % Initialize the previous cost matrix
P=eye(xn)*10;    
it=0;            % Counter for iterations
p_save=[];       % Track the cost matrices in all the iterations
k_save=[];       % Track the feedback gain matrix in each iterations

[K0,P0]=lqr(A,B,Q,R) % Calculate the ideal solution for comparion purpose
k_save=[norm(K-K0)];

while norm(P-P_old)>0.00002 & it<16 % stopping criterion for learning
    it=it+1                         % update and display the # of interations     
    P_old=P;                        % update the previous cost matrix
    QK=Q+K'*R*K;                    % update the Qk matrix
    Y=-XX*QK(:);                    % obtain the right-hand side of the equation
    X2=XX*kron(eye(xn),K');         % 
    X1=[Dxx,-X2-XU];                % obtain the left-hand side of the equation
    pp=inv(X1'*X1)*X1'*Y;           % solve the equations in the least-squares sense
    P=reshape_p(pp);                %
    p_save=[p_save,norm(P-P0)];
    
    BPv=pp(end-(xn*un-1):end);
    K=inv(R)*reshape(BPv,un,xn)/2
    k_save=[k_save,norm(K-K0)];
end

%%
figure(1)
     plot([0:length(p_save)-1],p_save,'o',[0:length(p_save)-1],p_save)
     axis([-0.5,it-.5,-5,15])
     legend('||P_k-P^*||')
     xlabel('Number of iterations')

figure(4)
     plot([0:length(k_save)-1],k_save,'^',[0:length(k_save)-1],k_save)
     axis([-0.5,it+0.5,-.5,2])
     legend('||K_k-K^*||')
     xlabel('Number of iterations')
     
% figure(7)
%      subplot(211)
%      plot([0:length(p_save)-1],p_save,'o',[0:length(p_save)-1],p_save,'Linewidth',2)
%      axis([-0.5,it-.5,-5,15])
%      legend('||P_k-P^*||')
%      xlabel('Number of iterations')
% 
%      subplot(212)
%      plot([0:length(k_save)-1],k_save,'^',[0:length(k_save)-1],k_save,'Linewidth',2)
%      axis([-0.5,it+0.5,-.5,2])
%      legend('||K_k-K^*||')
%      xlabel('Number of iterations')


%% Post-learning simulation
[tt,xx]=ode23(@mysys,[t(end) 200],X(end,:)');

%% fda
t_final=[t_save;tt];
x_final=[x_save;xx];

%% plot the trajectories
figure(2)
plot(t_final,x_final(:,1:6),'Linewidth',2)
axis([0,10,-100,200])
legend('x_1','x_2','x_3','x_4','x_5','x_6')
xlabel('Time (sec)')

figure(3)
plot(t_final,x_final(:,1:6),'Linewidth',2)
legend('x_1','x_2','x_3','x_4','x_5','x_6')
xlabel('Time (sec)')

figure(5)
plot(t_final,sqrt(sum(x_final(:,1:6).^2,2)),'Linewidth',2)
axis([0,200,-50,200])
legend('||x||')
xlabel('Time (sec)')

figure(6)
plot(t_final,3.6*x_final(:,1),'k-.',t_final, x_final(:,6),'-','Linewidth',2)
axis([0,10,-80,50])
legend('y_1 (MAF)','y_2 (MAP)')
xlabel('Time (sec)')





