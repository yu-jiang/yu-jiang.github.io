% This function reconstruct the P matrix from its distinct elements
function P=reshape_p(p)
global xn
P=zeros(xn);
ij=0;
for i=1:xn
    for j=1:i
     ij=ij+1;
     P(i,j)=p(ij);
     P(j,i)=P(i,j);
    end
end
end