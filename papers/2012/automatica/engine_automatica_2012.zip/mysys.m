function dX=mysys(t,X)
global A B xn un i1 i2 K flag
x=X(1:xn);

if t>=2;   % See if learning is stopped
    flag=0;  
end

if flag==1
        u=zeros(un,1);
        for i=i1
             u(1)=u(1)+sin(i*t)/length(i1); % constructing the exploration noise
        end 
        for i=i2
             u(2)=u(2)+sin(i*t)/length(i2);
        end
        u=10000*u;
else
        u=-K*x;
end

dx=A*x+B*u;
dxx=kron(x',x')';
dux=kron(x',u')';
dX=[dx;
    dxx;
    dux];
end